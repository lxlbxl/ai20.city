<?php
// backend/api/leads.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    try {
        $stmt = $pdo->query("SELECT * FROM leads ORDER BY created_at DESC");
        $leads = $stmt->fetchAll();
        jsonResponse(['status' => 'success', 'data' => $leads]);
    } catch (Exception $e) {
        jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
} elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        jsonResponse(['status' => 'error', 'message' => 'Invalid JSON input'], 400);
    }

    try {
        $sql = "INSERT INTO leads (
            first_name, last_name, email, phone, company, 
            industry, location, company_size, challenges, 
            ai_usage, timeline, budget, consent
        ) VALUES (
            :firstName, :lastName, :email, :phone, :company, 
            :industry, :location, :size, :challenges, 
            :aiUsage, :timeline, :budget, :consent
        )";

        $stmt = $pdo->prepare($sql);
        
        // Handle array to string conversion for challenges if needed
        $challenges = is_array($input['challenges']) ? implode(', ', $input['challenges']) : ($input['challenges'] ?? '');
        $consent = isset($input['consent']) ? 1 : 0;

        $stmt->execute([
            ':firstName' => $input['firstName'] ?? '',
            ':lastName' => $input['lastName'] ?? '',
            ':email' => $input['email'] ?? '',
            ':phone' => $input['phone'] ?? '',
            ':company' => $input['company'] ?? '',
            ':industry' => $input['industry'] ?? '',
            ':location' => $input['location'] ?? '',
            ':size' => $input['companySize'] ?? ($input['size'] ?? ''), // Handle potential naming mismatch
            ':challenges' => $challenges,
            ':aiUsage' => $input['aiUsage'] ?? '',
            ':timeline' => $input['timeline'] ?? '',
            ':budget' => $input['budget'] ?? '',
            ':consent' => $consent
        ]);

        jsonResponse(['status' => 'success', 'message' => 'Lead created successfully', 'id' => $pdo->lastInsertId()], 201);

    } catch (Exception $e) {
        jsonResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
} else {
    jsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
}
?>
